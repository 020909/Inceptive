// app/api/council/start/route.ts
// Creates a new council session in Supabase and returns the session_id + first agent to call.
// The frontend calls this first, then uses useCouncil hook to run the chain.

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'
import { AGENT_CHAINS } from '@/lib/council/config'

export async function POST(req: NextRequest) {
  const supabase = createRouteHandlerClient({ cookies })

  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json().catch(() => null)
  if (!body?.prompt) {
    return NextResponse.json({ error: 'Missing prompt' }, { status: 400 })
  }

  // Get the user's plan from your users table
  const { data: userData, error: userError } = await supabase
    .from('users')
    .select('plan, subscription_status')
    .eq('id', user.id)
    .single()

  if (userError || !userData) {
    return NextResponse.json({ error: 'Could not load user plan' }, { status: 500 })
  }

  // If subscription is not active, fall back to free
  const isActive = userData.subscription_status === 'active' || userData.subscription_status === 'trialing'
  const plan: string = isActive ? (userData.plan ?? 'free') : 'free'

  const chain = AGENT_CHAINS[plan] ?? AGENT_CHAINS.free
  const firstAgent = chain[0]

  // Create session
  const { data: session, error: insertError } = await supabase
    .from('council_sessions')
    .insert({
      user_id: user.id,
      prompt: body.prompt,
      plan,
      status: 'pending',
      current_agent: firstAgent,
      agents_completed: [],
      outputs: {},
    })
    .select('id')
    .single()

  if (insertError || !session) {
    return NextResponse.json({ error: 'Failed to create session' }, { status: 500 })
  }

  return NextResponse.json({
    session_id: session.id,
    plan,
    chain,           // full ordered list so frontend can show progress bar
    first_agent: firstAgent,
  })
}
