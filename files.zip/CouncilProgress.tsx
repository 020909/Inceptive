// components/council/CouncilProgress.tsx
// Drop this anywhere in your dashboard to show live council progress.
// Plug in the state from useCouncil().

'use client'

import { AgentResult, CouncilState } from '@/hooks/useCouncil'

interface Props {
  agents: AgentResult[]
  currentAgent: string | null
  status: CouncilState['status']
  finalOutput: string | null
  error: string | null
  onCancel?: () => void
}

export function CouncilProgress({
  agents,
  currentAgent,
  status,
  finalOutput,
  error,
  onCancel,
}: Props) {
  if (status === 'idle') return null

  return (
    <div className="w-full rounded-2xl border border-white/10 bg-black p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-white tracking-wide uppercase">
          Agent Council
        </h3>
        {status === 'running' && onCancel && (
          <button
            onClick={onCancel}
            className="text-xs text-white/40 hover:text-white/80 transition-colors"
          >
            Cancel
          </button>
        )}
        {status === 'done' && (
          <span className="text-xs text-emerald-400 font-medium">Complete</span>
        )}
        {status === 'error' && (
          <span className="text-xs text-red-400 font-medium">Failed</span>
        )}
      </div>

      {/* Agent list */}
      <div className="space-y-1.5">
        {agents.map((a) => (
          <AgentRow key={a.agent} agent={a} isActive={a.agent === currentAgent} />
        ))}
      </div>

      {/* Error */}
      {error && (
        <div className="rounded-lg bg-red-950/50 border border-red-800/40 p-3">
          <p className="text-xs text-red-400">{error}</p>
        </div>
      )}

      {/* Final output preview (Orchestrator output) */}
      {finalOutput && (
        <div className="rounded-lg bg-white/5 border border-white/10 p-4 max-h-64 overflow-y-auto">
          <p className="text-xs text-white/40 mb-2 uppercase tracking-wide font-medium">
            Final Output
          </p>
          <pre className="text-xs text-white/80 whitespace-pre-wrap font-mono leading-relaxed">
            {finalOutput}
          </pre>
        </div>
      )}
    </div>
  )
}

function AgentRow({ agent, isActive }: { agent: AgentResult; isActive: boolean }) {
  const statusConfig = {
    waiting: { dot: 'bg-white/20', text: 'text-white/30', label: '' },
    running: { dot: 'bg-amber-400 animate-pulse', text: 'text-amber-400', label: 'Running…' },
    done:    { dot: 'bg-emerald-400', text: 'text-emerald-400', label: 'Done' },
    error:   { dot: 'bg-red-500', text: 'text-red-400', label: 'Error' },
  }[agent.status]

  return (
    <div
      className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-colors ${
        isActive ? 'bg-white/5' : ''
      }`}
    >
      {/* Status dot */}
      <span className={`h-1.5 w-1.5 rounded-full flex-shrink-0 ${statusConfig.dot}`} />

      {/* Label */}
      <span className={`text-sm flex-1 ${agent.status === 'waiting' ? 'text-white/30' : 'text-white/80'}`}>
        {agent.label}
      </span>

      {/* Status text */}
      {statusConfig.label && (
        <span className={`text-xs ${statusConfig.text}`}>{statusConfig.label}</span>
      )}
    </div>
  )
}
