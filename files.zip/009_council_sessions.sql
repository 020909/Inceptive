-- Council Sessions Table
-- Stores one row per user-initiated council run.
-- Each agent reads this row, appends its output to `outputs`, and updates `current_agent`.

CREATE TABLE IF NOT EXISTS public.council_sessions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  prompt            TEXT NOT NULL,
  plan              TEXT NOT NULL CHECK (plan IN ('free', 'basic', 'pro', 'unlimited')),
  status            TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'done', 'failed')),
  current_agent     TEXT,                        -- which agent is running right now
  agents_completed  TEXT[] NOT NULL DEFAULT '{}', -- e.g. ['planner', 'ux_designer']
  outputs           JSONB NOT NULL DEFAULT '{}',  -- { planner: "...", coder: "...", etc. }
  final_output      TEXT,                         -- filled by Orchestrator at the end
  error             TEXT,                         -- filled if status = 'failed'
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index so the frontend hook can quickly poll by user + session
CREATE INDEX IF NOT EXISTS council_sessions_user_id_idx ON public.council_sessions(user_id);
CREATE INDEX IF NOT EXISTS council_sessions_status_idx  ON public.council_sessions(status);

-- RLS
ALTER TABLE public.council_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own sessions"
  ON public.council_sessions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own sessions"
  ON public.council_sessions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own sessions"
  ON public.council_sessions FOR UPDATE
  USING (auth.uid() = user_id);

-- Auto-update updated_at on any row change
CREATE OR REPLACE FUNCTION public.update_council_session_timestamp()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER council_sessions_updated_at
  BEFORE UPDATE ON public.council_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_council_session_timestamp();
