// app/api/council/[agent]/route.ts
// One route handles all 10 agents. Vercel calls this fresh each time = fresh 10s timer.
// The frontend calls /api/council/planner → gets { next: "ux_designer" } → calls that → etc.

import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'
import {
  AGENT_CHAINS,
  SYSTEM_PROMPTS,
  getNextAgent,
  isLastAgent,
} from '@/lib/council/config'

const OPENROUTER_API = 'https://openrouter.ai/api/v1/chat/completions'
const MODEL = 'google/gemini-2.0-flash-001'

// POST /api/council/[agent]
// Body: { session_id: string }
// Returns: { agent, output, next: string | null, done: boolean }
export async function POST(
  req: NextRequest,
  { params }: { params: { agent: string } }
) {
  const { agent } = params

  // Validate agent name
  if (!SYSTEM_PROMPTS[agent]) {
    return NextResponse.json({ error: `Unknown agent: ${agent}` }, { status: 400 })
  }

  const body = await req.json().catch(() => null)
  if (!body?.session_id) {
    return NextResponse.json({ error: 'Missing session_id' }, { status: 400 })
  }
  const { session_id } = body

  // Auth
  const supabase = createRouteHandlerClient({ cookies })
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // Load session
  const { data: session, error: sessionError } = await supabase
    .from('council_sessions')
    .select('*')
    .eq('id', session_id)
    .eq('user_id', user.id)
    .single()

  if (sessionError || !session) {
    return NextResponse.json({ error: 'Session not found' }, { status: 404 })
  }

  if (session.status === 'done' || session.status === 'failed') {
    return NextResponse.json({ error: `Session already ${session.status}` }, { status: 409 })
  }

  // Make sure this agent is actually in the chain for this plan
  const chain = AGENT_CHAINS[session.plan] ?? AGENT_CHAINS.free
  if (!chain.includes(agent)) {
    return NextResponse.json(
      { error: `Agent "${agent}" is not in the chain for plan "${session.plan}"` },
      { status: 400 }
    )
  }

  // Mark session as running this agent
  await supabase
    .from('council_sessions')
    .update({ status: 'running', current_agent: agent })
    .eq('id', session_id)

  // Build the AI prompt
  // Each agent sees: its system prompt + the original task + all previous agents' outputs
  const previousOutputs = Object.entries(session.outputs as Record<string, string>)
    .map(([role, output]) => `\n\n=== ${role.toUpperCase().replace('_', ' ')} OUTPUT ===\n${output}`)
    .join('')

  const userMessage = previousOutputs
    ? `ORIGINAL TASK:\n${session.prompt}${previousOutputs}`
    : `ORIGINAL TASK:\n${session.prompt}`

  // Call AI
  let agentOutput = ''
  try {
    const aiRes = await fetch(OPENROUTER_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'HTTP-Referer': process.env.NEXT_PUBLIC_APP_URL ?? 'https://inceptive.app',
        'X-Title': 'Inceptive Council',
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: 'system', content: SYSTEM_PROMPTS[agent] },
          { role: 'user', content: userMessage },
        ],
        max_tokens: 2500,
        temperature: 0.3, // lower = more consistent, less hallucination
      }),
    })

    if (!aiRes.ok) {
      const errText = await aiRes.text()
      throw new Error(`OpenRouter error ${aiRes.status}: ${errText}`)
    }

    const aiData = await aiRes.json()
    agentOutput = aiData.choices?.[0]?.message?.content ?? ''

    if (!agentOutput) {
      throw new Error('AI returned empty response')
    }
  } catch (err: any) {
    // Mark session failed and return error
    await supabase
      .from('council_sessions')
      .update({
        status: 'failed',
        error: err.message,
        current_agent: agent,
      })
      .eq('id', session_id)

    return NextResponse.json(
      { error: 'AI call failed', detail: err.message },
      { status: 500 }
    )
  }

  // Persist agent output
  const nextAgent = getNextAgent(session.plan, agent)
  const done = isLastAgent(session.plan, agent)
  const updatedOutputs = { ...(session.outputs as object), [agent]: agentOutput }

  const { error: updateError } = await supabase
    .from('council_sessions')
    .update({
      outputs: updatedOutputs,
      agents_completed: [...(session.agents_completed ?? []), agent],
      current_agent: nextAgent,
      status: done ? 'done' : 'running',
      ...(done ? { final_output: agentOutput } : {}),
    })
    .eq('id', session_id)

  if (updateError) {
    console.error('Failed to save agent output:', updateError)
    // Don't fail the request — output was generated, just couldn't save progress marker
  }

  return NextResponse.json({
    agent,
    output: agentOutput,
    next: nextAgent,      // null if this was the last agent
    done,
    session_id,
  })
}

// POST /api/council/start
// Separate endpoint to create a new session and return the session_id + first agent name
// (Handled in app/api/council/start/route.ts — see that file)
