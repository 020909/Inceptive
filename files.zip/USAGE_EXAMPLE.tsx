// HOW TO WIRE IT INTO YOUR DASHBOARD CHAT
// ==========================================
// This is NOT a file to copy — it's an example showing where to add the hook.
// Your actual dashboard is at app/dashboard/page.tsx (or similar).

'use client'

import { useCouncil } from '@/hooks/useCouncil'
import { CouncilProgress } from '@/components/council/CouncilProgress'

export default function DashboardPage() {
  const council = useCouncil()

  // Your existing prompt submit handler — just add this check:
  const handleSubmit = async (prompt: string) => {
    // Your existing logic already checks isWebsiteBuildTask server-side.
    // For the council path, just call:
    if (isWebsiteBuildTask(prompt)) {
      await council.startCouncil(prompt)
      return
    }
    // ... your existing normal chat path
  }

  return (
    <div>
      {/* Your existing dashboard UI */}

      {/* Add the progress panel — it only shows when council is running */}
      <CouncilProgress
        agents={council.agents}
        currentAgent={council.currentAgent}
        status={council.status}
        finalOutput={council.finalOutput}
        error={council.error}
        onCancel={council.cancel}
      />

      {/* Your existing chat input */}
    </div>
  )
}

// Simple client-side keyword check (the real check is server-side already)
function isWebsiteBuildTask(prompt: string): boolean {
  const keywords = ['website', 'landing page', 'frontend', 'build a site', 'web app', 'homepage']
  return keywords.some(k => prompt.toLowerCase().includes(k))
}
