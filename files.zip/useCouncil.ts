// hooks/useCouncil.ts
// Drop this hook anywhere in the dashboard.
// Call startCouncil(prompt) and it runs the full agent chain automatically.
// Each agent fires the next one when it finishes — no Vercel timeout issues.

import { useState, useCallback, useRef } from 'react'
import { AGENT_LABELS } from '@/lib/council/config'

export type AgentStatus = 'waiting' | 'running' | 'done' | 'error'

export interface AgentResult {
  agent: string
  label: string
  output: string
  status: AgentStatus
}

export interface CouncilState {
  sessionId: string | null
  plan: string | null
  chain: string[]
  agents: AgentResult[]
  currentAgent: string | null
  finalOutput: string | null
  status: 'idle' | 'running' | 'done' | 'error'
  error: string | null
}

const initialState: CouncilState = {
  sessionId: null,
  plan: null,
  chain: [],
  agents: [],
  currentAgent: null,
  finalOutput: null,
  status: 'idle',
  error: null,
}

export function useCouncil() {
  const [state, setState] = useState<CouncilState>(initialState)
  const abortRef = useRef(false) // lets us cancel mid-chain if needed

  // Update a single agent's status/output in the list
  const updateAgent = (agent: string, patch: Partial<AgentResult>) => {
    setState(prev => ({
      ...prev,
      agents: prev.agents.map(a => a.agent === agent ? { ...a, ...patch } : a),
    }))
  }

  const startCouncil = useCallback(async (prompt: string) => {
    abortRef.current = false

    // Reset state
    setState({ ...initialState, status: 'running' })

    // Step 1: Create session, get chain
    let sessionId: string
    let chain: string[]
    let firstAgent: string
    let plan: string

    try {
      const res = await fetch('/api/council/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? 'Failed to start council')

      sessionId = data.session_id
      chain = data.chain
      firstAgent = data.first_agent
      plan = data.plan
    } catch (err: any) {
      setState(prev => ({ ...prev, status: 'error', error: err.message }))
      return
    }

    // Build the initial agents list (all waiting)
    const initialAgents: AgentResult[] = chain.map(a => ({
      agent: a,
      label: AGENT_LABELS[a] ?? a,
      output: '',
      status: 'waiting' as AgentStatus,
    }))

    setState(prev => ({
      ...prev,
      sessionId,
      plan,
      chain,
      currentAgent: firstAgent,
      agents: initialAgents,
    }))

    // Step 2: Run the chain — each agent calls the next
    let nextAgent: string | null = firstAgent

    while (nextAgent !== null) {
      if (abortRef.current) break

      const currentAgent = nextAgent
      updateAgent(currentAgent, { status: 'running' })
      setState(prev => ({ ...prev, currentAgent }))

      try {
        const res = await fetch(`/api/council/${currentAgent}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId }),
        })
        const data = await res.json()

        if (!res.ok) throw new Error(data.error ?? `Agent ${currentAgent} failed`)

        updateAgent(currentAgent, { status: 'done', output: data.output })

        if (data.done) {
          // Orchestrator finished — we're done
          setState(prev => ({
            ...prev,
            currentAgent: null,
            finalOutput: data.output,
            status: 'done',
          }))
          nextAgent = null
        } else {
          nextAgent = data.next
        }
      } catch (err: any) {
        updateAgent(currentAgent, { status: 'error' })
        setState(prev => ({
          ...prev,
          status: 'error',
          error: `${currentAgent} failed: ${err.message}`,
          currentAgent: null,
        }))
        return
      }
    }
  }, [])

  const cancel = useCallback(() => {
    abortRef.current = true
    setState(prev => ({
      ...prev,
      status: 'idle',
      currentAgent: null,
      error: 'Cancelled',
    }))
  }, [])

  const reset = useCallback(() => {
    abortRef.current = true
    setState(initialState)
  }, [])

  return {
    ...state,
    startCouncil,
    cancel,
    reset,
  }
}
